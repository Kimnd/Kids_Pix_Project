//Project by: Ryan Lim,	Ethan <INSERT NAME HERE>
//, and Marion Fiona Gallagher.
//A drawing program that lets the user draw in three colors,
//erase things, and clear the screen. Exciting things, all!
/*import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.*;

public class DrawGUI extends JPanel {

	private JRadioButton pen_1, pen_2, pen_3, eraser;
	private static Color currentColor = Color.PINK;
	private final static Color PURPLE = new Color(204, 0, 204);
	private final static Color FOREST = new Color(0, 153, 0);
	private final static Color SUNNY = new Color(255, 179, 0);
	private JButton clearButton;
	private static boolean canDraw;
	private final static int DIAMETER = 10;
	private ArrayList<ColoredPoint> myPoints;
	public DrawGUI() {
		//super("Welcome to Drawing!");
		//setSize(600, 600);
		
		//Container canvas = getContentPane();
		setBackground(Color.PINK);
		myPoints = new ArrayList<ColoredPoint>();
		
		//JPanel mainPanel = new JPanel();
		//mainPanel.setBackground(Color.GRAY);
		//canvas.setLayout(new BorderLayout());
		//canvas.add(mainPanel, BorderLayout.PAGE_END);
		
		JPanel drawPanel = new JPanel();
		ButtonGroup myGroup = new ButtonGroup();
		
		pen_1 = new JRadioButton("Purple");
		drawPanel.add(pen_1);
		pen_1.addActionListener(new ToolListener());
		pen_2 = new JRadioButton("Puke");
		drawPanel.add(pen_2);
		pen_2.addActionListener(new ToolListener());
		pen_3 = new JRadioButton("Orange");
		drawPanel.add(pen_3);
		pen_3.addActionListener(new ToolListener());
		eraser = new JRadioButton("Eraser");
		drawPanel.add(eraser);
		eraser.addActionListener(new ToolListener());
		clearButton = new JButton("Clear Drawing");
		drawPanel.add(clearButton);
		clearButton.addActionListener(new ToolListener());

		myGroup.add(pen_1);
		myGroup.add(pen_2);
		myGroup.add(pen_3);
		myGroup.add(eraser);
		
		this.add(drawPanel);
		
		this.addMouseMotionListener(new CanvasListener());
		this.addMouseListener(new CanvasListener());
		canDraw = false;
	}

	//getters and setters for canIDraw, the variable that specifies whether or not a user can draw on the canvas
	public static boolean getCanDraw () {
		return canDraw;
	}

	public static void setCanDraw (boolean canIDraw) {
		canDraw = canIDraw;
	}
	
	public static Color getCurrentColor() {
		return currentColor;
	}
	
	@Override
	public void paintComponent(Graphics pen) {
		super.paintComponent(pen);
		for(ColoredPoint point : myPoints) {
			int x = (int) point.getXCoord();
			int y = (int) point.getYCoord();
			pen.setColor(point.getPointColor());
			pen.fillOval(x, y, DIAMETER, DIAMETER);
		}
	}
	
	private class CanvasListener extends MouseAdapter {
		@Override
		public void mouseClicked (MouseEvent event){
			if (canDraw == true) {
				canDraw = false;
			} else if (canDraw == false) {
				canDraw = true;
			} System.out.println(canDraw);
		}
		@Override
		public void mouseMoved(MouseEvent event) {
			if(canDraw) {
				ColoredPoint point = new ColoredPoint(event.getPoint(), currentColor);
				myPoints.add(point);
			}
			repaint();
		}
	}
//the class to tell the program what to do if the user hits any of the buttons
	private class ToolListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			//the logic that tells the program what to do when the user interacts with stuff
			if (pen_1.isSelected()) {
				currentColor = PURPLE;
			} else if (pen_2.isSelected()) {
				currentColor = FOREST;
			} else if (pen_3.isSelected()) {
				currentColor = SUNNY;
			} else if (eraser.isSelected()) {
				currentColor = Color.PINK;
			} //this is seperate because clearing the canvas isn't related which other pens are selected
			if (arg0.getSource() == clearButton) {
				myPoints.clear();
			}
		}
	}
	
//	private class ButtonListener implements 

	public static void main(String args[]) {
		System.out.println("running");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				JFrame frame = new JFrame("Welcome to Drawing!");
				frame.setSize(600, 600);
				// create an object of your class
				DrawGUI panel = new DrawGUI();
				frame.getContentPane().add(panel);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}*/